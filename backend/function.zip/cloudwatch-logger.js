const { CloudWatchLogsClient, PutLogEventsCommand } = require('@aws-sdk/client-cloudwatch-logs');

console.log({
  AWS_REGION: process.env.AWS_REGION,
  AWS_ACCESS_KEY_ID: process.env.AWS_ACCESS_KEY_ID,
  AWS_SECRET_ACCESS_KEY: process.env.AWS_SECRET_ACCESS_KEY,
});

const cloudwatchLogs = new CloudWatchLogsClient({
  region: process.env.AWS_REGION,
  credentials: {
    accessKeyId: process.env.AWS_ACCESS_KEY_ID,
    secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY,
  },
});

const logGroupName = process.env.CLOUDWATCH_LOG_GROUP;
const logStreamName = process.env.CLOUDWATCH_LOG_STREAM;
let sequenceToken = null;

async function logToCloudWatch(level, event, details) {
  const timestamp = new Date().toISOString();
  const message = JSON.stringify({ level, event, details, timestamp });

  const params = {
    logGroupName,
    logStreamName,
    logEvents: [{ message, timestamp: Date.now() }],
  };

  if (sequenceToken) {
    params.sequenceToken = sequenceToken;
  }

  try {
    const command = new PutLogEventsCommand(params);
    const response = await cloudwatchLogs.send(command);
    sequenceToken = response.nextSequenceToken;
  } catch (error) {
    console.error('Failed to log to CloudWatch:', error.message);
  }
}

module.exports = logToCloudWatch;
